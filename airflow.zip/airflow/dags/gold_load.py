from airflow import DAG # type: ignore
from airflow.operators.python import PythonOperator
from datetime import datetime
from pymongo import MongoClient

def aggregate_to_gold():
    
    client = MongoClient("mongodb://root:example@mongo:27017/admin")  

  
    db_bronze = client["bronze"]
    db_gold = client["gold"]

    estabelecimentos = db_bronze["estabelecimentos"]
    gold_collection = db_gold["gold"]


    pipeline = [
        {
            "$lookup": {
                "from": "cnaes",
                "localField": "cnae_principal",
                "foreignField": "codigo",
                "as": "filter1"
            }
        },
        {
            "$lookup": {
                "from": "empresas",
                "localField": "cnpj_basico",
                "foreignField": "cnpj_basico",
                "as": "filter2"
            }
        },
        {
            "$lookup": {
                "from": "socios",
                "localField": "cnpj_basico",
                "foreignField": "cnpj_basico",
                "as": "filter3"
            }
        },
        {
            "$project": {
                "tipo_logradouro": 1,
                "numero": 1,
                "cep": 1,
                "uf": 1,
                "_id": 0,
                "filter1": {
                    "$arrayElemAt": ["$filter1", 0]
                },
                "filter2": {
                    "$arrayElemAt": ["$filter2", 0]
                },
                "filter3": {
                    "$arrayElemAt": ["$filter3", 0]
                }
            }
        },
        {
            "$project": {
                "tipo_logradouro": 1,
                "numero": 1,
                "cep": 1,
                "uf": 1,
                "_id": 0,
                "filter1": {
                    "codigo": "$filter1.codigo",
                    "descricao": "$filter1.descricao"
                },
                "filter2": {
                    "cnpj": "$filter2.cnpj_basico",
                    "razao_social": "$filter2.razao_social"
                },
                "filter3": {
                    "nome": "$filter3.nome_socio",
                    "representante": "$filter3.representante_legal"
                }
            }
        }
    ]

    
    results = list(estabelecimentos.aggregate(pipeline))


    if results:
        gold_collection.insert_many(results)
        print(f"{len(results)} documentos inseridos na coleção 'gold'.")
    else:
        print("Nenhum documento retornado pelo aggregate.")


with DAG(
    dag_id="mongo_aggregate_to_gold",
    start_date=datetime(2023, 1, 1),
    schedule=None, 
    catchup=False,
    tags=["mongo", "etl", "gold"]
) as dag:

    executar_aggregate = PythonOperator(
        task_id="executar_aggregate_e_inserir_gold",
        python_callable=aggregate_to_gold
    )

    executar_aggregate
