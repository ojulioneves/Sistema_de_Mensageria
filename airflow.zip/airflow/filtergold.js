db.estabelecimentos.aggregate([
    {
        $lookup: {
            from: "cnaes",
            localField: "cnae_principal",
            foreignField: "codigo",
            as: "filter1"
        },
        
    },
    {
        $lookup: {
            from: "empresas",
            localField: "cnpj_basico",
            foreignField: "cnpj_basico",
            as: "filter2"
        },

    },
    {
        $lookup: {
            from: "socios",
            localField: "cnpj_basico",
            foreignField: "cnpj_basico",
            as: "filter3"
        },

    },
    {
        $project:{
            tipo_logradouro: 1,
            numero: 1,
            cep: 1,
            uf: 1,
            _id: 0,
            filter1: {
                $arrayElemAt: ["$filter1", 0]
            },
            filter2: {
                $arrayElemAt: ["$filter2", 0]
            },
            filter3: {
                $arrayElemAt: ["$filter3", 0]
            },
            
        }
    },
    {
        $project:{
            tipo_logradouro: 1,
            numero: 1,
            cep: 1,
            uf: 1,
            _id: 0,
            filter1: {
                "codigo": "$filter1.codigo",
                "descricao": "$filter1.descricao"
            },
            filter2: {
                "cnpj": "$filter2.cnpj_basico", 
                "razao_social": "$filter2.razao_social"
            },
            filter3: {
                "nome": "$filter3.nome_socio", 
                "representante": "$filter3.representante_legal"
            }
        }
    }
])